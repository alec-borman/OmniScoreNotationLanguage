import React, { useState, useEffect, useRef, useLayoutEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { Terminal as TerminalIcon, Cpu, Zap, Activity } from 'lucide-react';

// --- CORE: OMNISCORE COMPILER ENGINE (PURE TYPESCRIPT) ---

type TokenType = 'NOTE' | 'REST' | 'DURATION' | 'BARLINE' | 'COMMAND' | 'IDENTIFIER' | 'NUMBER' | 'UNKNOWN';

interface Token {
  type: TokenType;
  value: string;
  line: number;
  col: number;
}

interface SoundEvent {
  type: 'NOTE' | 'REST';
  pitch?: string;
  midi?: number;
  duration: number; // beats
  start: number; // beats
  velocity?: number;
}

interface CompileResult {
  success: boolean;
  events: SoundEvent[];
  logs: string[];
  timeMs: number;
}

class OmniLexer {
  private input: string;
  private pos = 0;
  private line = 1;
  private col = 1;

  constructor(input: string) { this.input = input; }

  tokenize(): Token[] {
    const tokens: Token[] = [];
    while (this.pos < this.input.length) {
      const char = this.input[this.pos];
      if (/\s/.test(char)) {
        if (char === '\n') { this.line++; this.col = 1; } else { this.col++; }
        this.pos++; continue;
      }
      if (char === '/' && this.input[this.pos + 1] === '/') {
        while (this.pos < this.input.length && this.input[this.pos] !== '\n') this.pos++;
        continue;
      }
      if (char === '@') {
        const start = this.pos++;
        while (this.pos < this.input.length && /[a-zA-Z]/.test(this.input[this.pos])) this.pos++;
        tokens.push(this.tok('COMMAND', this.input.slice(start, this.pos)));
        continue;
      }
      const noteMatch = this.input.slice(this.pos).match(/^([A-G][#b]?)(-?\d+)?/);
      if (noteMatch && /[A-G]/.test(noteMatch[1])) {
        tokens.push(this.tok('NOTE', noteMatch[0]));
        this.pos += noteMatch[0].length; this.col += noteMatch[0].length;
        continue;
      }
      if (/[Rr]/.test(char)) {
        tokens.push(this.tok('REST', char));
        this.pos++; this.col++;
        continue;
      }
      const durMatch = this.input.slice(this.pos).match(/^(1\/\d+|\d+(\.\d+)?|[qhwes])/);
      if (durMatch && (/\d/.test(durMatch[0]) || ['q','h','w','e','s'].includes(durMatch[0]))) {
         tokens.push(this.tok('DURATION', durMatch[0]));
         this.pos += durMatch[0].length; this.col += durMatch[0].length;
         continue;
      }
      if (/[a-zA-Z_]/.test(char)) {
        const start = this.pos;
        while (this.pos < this.input.length && /[a-zA-Z0-9_:]/.test(this.input[this.pos])) this.pos++;
        tokens.push(this.tok('IDENTIFIER', this.input.slice(start, this.pos)));
        continue;
      }
      if (/\d/.test(char)) {
         const start = this.pos;
         while (this.pos < this.input.length && /[\d.]/.test(this.input[this.pos])) this.pos++;
         tokens.push(this.tok('NUMBER', this.input.slice(start, this.pos)));
         continue;
      }
      tokens.push(this.tok('UNKNOWN', char));
      this.pos++; this.col++;
    }
    return tokens;
  }

  private tok(type: TokenType, value: string): Token {
    return { type, value, line: this.line, col: this.col };
  }
}

class OmniCompiler {
  private state = { octave: 4, duration: 1.0, time: 0 };
  
  compile(source: string): CompileResult {
    const start = performance.now();
    const logs: string[] = [];
    const events: SoundEvent[] = [];
    
    try {
      const lexer = new OmniLexer(source);
      const tokens = lexer.tokenize();
      this.state = { octave: 4, duration: 1.0, time: 0 };
      
      let i = 0;
      while (i < tokens.length) {
        const t = tokens[i++];
        if (t.type === 'NOTE') {
          const match = t.value.match(/^([A-G][#b]?)(-?\d+)?$/);
          if (!match) continue;
          
          if (match[2]) this.state.octave = parseInt(match[2]);
          const octave = this.state.octave;
          
          let dur = this.state.duration;
          if (i < tokens.length && tokens[i].type === 'DURATION') {
            dur = this.parseDuration(tokens[i++].value);
            this.state.duration = dur;
          }

          const notes: Record<string, number> = { 'C':0, 'C#':1, 'D':2, 'D#':3, 'E':4, 'F':5, 'F#':6, 'G':7, 'G#':8, 'A':9, 'A#':10, 'B':11 };
          const base = notes[match[1]] ?? 0;
          
          events.push({
            type: 'NOTE',
            pitch: `${match[1]}${octave}`,
            midi: (octave + 1) * 12 + base,
            duration: dur,
            start: this.state.time
          });
          this.state.time += dur;
        } else if (t.type === 'REST') {
          let dur = this.state.duration;
          if (i < tokens.length && tokens[i].type === 'DURATION') {
            dur = this.parseDuration(tokens[i++].value);
            this.state.duration = dur;
          }
          events.push({ type: 'REST', duration: dur, start: this.state.time });
          this.state.time += dur;
        } else if (t.type === 'COMMAND') {
           // Basic command handling
           if (t.value === '@tempo' && i < tokens.length && tokens[i].type === 'NUMBER') i++;
        }
      }
      
      return { success: true, events, logs, timeMs: performance.now() - start };
    } catch (e: any) {
      return { success: false, events: [], logs: [e.message], timeMs: performance.now() - start };
    }
  }

  private parseDuration(val: string): number {
    const map: any = { w:4, h:2, q:1, e:0.5, s:0.25 };
    if (map[val]) return map[val];
    if (val.includes('/')) {
      const [n, d] = val.split('/').map(Number);
      return (n/d)*4;
    }
    return parseFloat(val);
  }
}

// --- VIRTUAL FILE SYSTEM ---

const SEED_FILES: Record<string, string> = {
  'main.omni': `// OmniScore - First Principles
@tempo 128
@inst sine

m1:
  C4 q E G B4
  C5 e D C B4 A q R

m2:
  C3 w`,
  'scale.omni': `// C Major Scale
C4 q D E F G A B C5`
};

// --- REACT COMPONENTS ---

const Terminal = () => {
  const [files, setFiles] = useState(SEED_FILES);
  const [history, setHistory] = useState<string[]>(['OmniScore v1.1.0 (release) [wasm32-unknown-unknown]', 'Type "help" for instructions.']);
  const [input, setInput] = useState('');
  const [cwd] = useState('/usr/home/omni');
  const [isEditing, setIsEditing] = useState<string | null>(null); // filename if editing
  const [editContent, setEditContent] = useState('');
  const [visualizerData, setVisualizerData] = useState<SoundEvent[] | null>(null);
  
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const compiler = new OmniCompiler();

  useEffect(() => {
    if (bottomRef.current) bottomRef.current.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  useEffect(() => {
    if (!isEditing && !visualizerData) inputRef.current?.focus();
  }, [isEditing, visualizerData]);

  const print = (text: string) => setHistory(prev => [...prev, text]);

  const handleCommand = async (cmdStr: string) => {
    const args = cmdStr.trim().split(/\s+/);
    const cmd = args[0];
    const rest = args.slice(1);

    print(`guest@omni:${cwd}$ ${cmdStr}`);

    switch (cmd) {
      case 'help':
        print('Available commands:');
        print('  ls               List files');
        print('  cat [file]       Display file content');
        print('  nano [file]      Edit file');
        print('  omnic build [f]  Compile OmniScore file');
        print('  omnic run [f]    Compile and visualize');
        print('  seed [num]       Generate random score');
        print('  clear            Clear terminal');
        break;
      case 'clear':
        setHistory([]);
        break;
      case 'ls':
        print(Object.keys(files).join('  '));
        break;
      case 'cat':
        if (!rest[0]) print('Usage: cat [filename]');
        else if (!files[rest[0]]) print(`Error: ${rest[0]} not found`);
        else print(files[rest[0]]);
        break;
      case 'nano':
      case 'edit':
        if (!rest[0]) print('Usage: nano [filename]');
        else {
          setIsEditing(rest[0]);
          setEditContent(files[rest[0]] || '');
        }
        break;
      case 'omnic':
        if (rest[0] === 'build') {
          const fname = rest[1];
          if (!fname || !files[fname]) { print('Error: File not found'); break; }
          const res = compiler.compile(files[fname]);
          print(`Compiling ${fname}...`);
          if (res.success) {
             print(`Finished dev [unoptimized + debuginfo] target(s) in ${res.timeMs.toFixed(2)}ms`);
             print(`Generated ${res.events.length} sound events.`);
          } else {
             print(`Error: ${res.logs[0]}`);
          }
        } else if (rest[0] === 'run') {
          const fname = rest[1];
          if (!fname || !files[fname]) { print('Error: File not found'); break; }
          const res = compiler.compile(files[fname]);
          if (res.success) {
            print(`Running ${fname}... (Press ESC to exit view)`);
            setVisualizerData(res.events);
          }
        } else {
          print('omnic: subcommand required (build, run)');
        }
        break;
      case 'seed':
         const id = parseInt(rest[0]) || Date.now();
         const newFile = `gen_${id}.omni`;
         const notes = ['C', 'D', 'E', 'F', 'G', 'A', 'B'];
         let content = `// Seed ${id}\n@tempo 140\nm1:\n`;
         for(let i=0; i<16; i++) {
            const n = notes[Math.floor(Math.random()*notes.length)];
            const o = 3 + Math.floor(Math.random()*3);
            const d = Math.random() > 0.5 ? 'q' : '8';
            content += `  ${n}${o} ${d}\n`;
         }
         setFiles(prev => ({...prev, [newFile]: content}));
         print(`Generated ${newFile} from seed ${id}`);
         break;
      case '':
        break;
      default:
        print(`command not found: ${cmd}`);
    }
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleCommand(input);
      setInput('');
    }
  };

  const saveFile = () => {
    if (isEditing) {
      setFiles(prev => ({...prev, [isEditing]: editContent}));
      setIsEditing(null);
      print(`root: Wrote ${editContent.length} bytes to ${isEditing}`);
    }
  };

  // --- RENDERERS ---

  if (visualizerData) {
    return <Oscilloscope events={visualizerData} onClose={() => setVisualizerData(null)} />;
  }

  if (isEditing) {
    return (
      <div className="h-screen w-full bg-black text-gray-200 font-mono flex flex-col p-4">
        <div className="bg-gray-800 text-white px-2 py-1 mb-2 flex justify-between">
          <span>GNU nano 5.4</span>
          <span>{isEditing}</span>
          <span>Modified</span>
        </div>
        <textarea 
          value={editContent}
          onChange={e => setEditContent(e.target.value)}
          className="flex-1 bg-black resize-none focus:outline-none"
          autoFocus
        />
        <div className="mt-2 flex gap-4 text-sm">
          <button onClick={saveFile} className="bg-white text-black px-2">^O Write Out</button>
          <button onClick={() => setIsEditing(null)} className="px-2">^X Exit</button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-full bg-[#0d0d0d] text-[#00ff41] font-mono p-4 overflow-hidden flex flex-col selection:bg-[#00ff41] selection:text-black">
      {/* Scanline overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-10 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))]" style={{backgroundSize: "100% 2px, 3px 100%"}}></div>
      
      <div className="flex-1 overflow-y-auto z-10 custom-scrollbar pb-12">
        {history.map((line, i) => (
          <div key={i} className="whitespace-pre-wrap mb-1">{line}</div>
        ))}
        <div className="flex items-center gap-2 mt-2">
          <span className="text-blue-500 font-bold">guest@omni:{cwd}$</span>
          <input 
            ref={inputRef}
            type="text" 
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={onKeyDown}
            className="flex-1 bg-transparent border-none outline-none text-[#00ff41] caret-[#00ff41]"
            autoFocus
          />
        </div>
        <div ref={bottomRef} />
      </div>
      
      <div className="z-10 text-xs text-gray-600 border-t border-gray-800 pt-2 flex justify-between">
        <span>OmniScore CLI 1.1.0</span>
        <span>mem: 64MB</span>
      </div>
    </div>
  );
};

const Oscilloscope = ({ events, onClose }: { events: SoundEvent[], onClose: () => void }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const startTime = useRef(Date.now());
  const reqRef = useRef(0);

  // Pre-calculate view bounds
  const totalBeats = events.reduce((max, e) => Math.max(max, e.start + e.duration), 0);
  const BPM = 120;
  const pixelsPerBeat = 100;
  
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if(e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  useLayoutEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;

    const render = () => {
      // Resize
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      const w = canvas.width;
      const h = canvas.height;
      const now = (Date.now() - startTime.current) / 1000; // seconds
      const beatTime = now * (BPM / 60);

      // Background
      ctx.fillStyle = '#050505';
      ctx.fillRect(0, 0, w, h);

      // Grid
      ctx.strokeStyle = '#1a1a1a';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < w; i += 50) { ctx.moveTo(i, 0); ctx.lineTo(i, h); }
      for (let i = 0; i < h; i += 50) { ctx.moveTo(0, i); ctx.lineTo(w, i); }
      ctx.stroke();

      // Playhead
      const playheadX = 200;
      
      // Draw Notes relative to playhead
      ctx.save();
      ctx.translate(playheadX - (beatTime * pixelsPerBeat), 0);

      events.forEach(e => {
        if (e.type !== 'NOTE' || !e.midi) return;
        const x = e.start * pixelsPerBeat;
        const width = e.duration * pixelsPerBeat - 4;
        // Map MIDI to Y: C4(60) -> Center
        const y = h/2 - (e.midi - 60) * 15;
        
        const isActive = beatTime >= e.start && beatTime < (e.start + e.duration);
        
        ctx.fillStyle = isActive ? '#00ff41' : '#003300';
        ctx.shadowBlur = isActive ? 15 : 0;
        ctx.shadowColor = '#00ff41';
        ctx.fillRect(x, y, width, 10);
        
        // Label
        if (width > 20) {
            ctx.fillStyle = isActive ? '#000' : '#00ff41';
            ctx.font = '10px monospace';
            ctx.fillText(e.pitch || '', x + 2, y + 9);
        }
      });
      ctx.restore();

      // Playhead Line
      ctx.strokeStyle = '#ff0000';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(playheadX, 0);
      ctx.lineTo(playheadX, h);
      ctx.stroke();

      // HUD
      ctx.fillStyle = '#00ff41';
      ctx.font = '14px monospace';
      ctx.fillText(`T: ${beatTime.toFixed(2)}`, 20, 30);
      ctx.fillText(`EVENTS: ${events.length}`, 20, 50);
      ctx.fillText(`[ESC] TO EXIT`, 20, 70);

      if (beatTime < totalBeats + 2) {
        reqRef.current = requestAnimationFrame(render);
      } else {
        ctx.fillStyle = '#fff';
        ctx.fillText('PLAYBACK FINISHED', w/2 - 50, h/2);
      }
    };
    reqRef.current = requestAnimationFrame(render);
    return () => cancelAnimationFrame(reqRef.current);
  }, [events]);

  return <canvas ref={canvasRef} className="fixed inset-0 z-50 cursor-none" />;
};

const App = () => {
  return <Terminal />;
};

const root = createRoot(document.getElementById('root')!);
root.render(<App />);
