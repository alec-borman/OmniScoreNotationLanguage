import React, { useState, useEffect, useMemo, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { Terminal, Play, Save, Box, Layers, AlertCircle, CheckCircle, Cpu, FileJson, Music } from 'lucide-react';

// --- TYPE DEFINITIONS: OMNISCORE COMPILER ---

type TokenType = 'NOTE' | 'REST' | 'DURATION' | 'BARLINE' | 'COMMAND' | 'IDENTIFIER' | 'NUMBER' | 'WHITESPACE' | 'UNKNOWN';

interface Token {
  type: TokenType;
  value: string;
  line: number;
  col: number;
}

interface NoteEvent {
  type: 'NOTE';
  pitch: string; // Scientific pitch e.g. C#4
  midiNumber: number;
  duration: number; // in beats
  startTime: number; // in beats
  velocity: number;
}

interface RestEvent {
  type: 'REST';
  duration: number;
  startTime: number;
}

type SoundEvent = NoteEvent | RestEvent;

interface CompilationResult {
  success: boolean;
  events: SoundEvent[];
  errors: CompilerError[];
  logs: string[];
}

interface CompilerError {
  code: string;
  message: string;
  line: number;
}

// --- LEXER ENGINE ---

const KEYWORDS = ['@tempo', '@inst', '@meta'];
const NOTE_REGEX = /^([A-G][#b]?)(-?\d+)?/;
const DURATION_REGEX = /^(1\/\d+|\d+(\.\d+)?|q|h|w|e|s)/; 

class Lexer {
  private input: string;
  private pos: number = 0;
  private line: number = 1;
  private col: number = 1;

  constructor(input: string) {
    this.input = input;
  }

  tokenize(): Token[] {
    const tokens: Token[] = [];
    while (this.pos < this.input.length) {
      const char = this.input[this.pos];

      // Whitespace
      if (/\s/.test(char)) {
        if (char === '\n') {
          this.line++;
          this.col = 1;
        } else {
          this.col++;
        }
        this.pos++;
        continue;
      }

      // Comments
      if (char === '/' && this.input[this.pos + 1] === '/') {
        while (this.pos < this.input.length && this.input[this.pos] !== '\n') {
          this.pos++;
        }
        continue;
      }

      // Barline
      if (char === '|') {
        tokens.push({ type: 'BARLINE', value: '|', line: this.line, col: this.col });
        this.pos++; this.col++;
        continue;
      }

      // Commands
      if (char === '@') {
        const start = this.pos;
        this.pos++; // skip @
        while (this.pos < this.input.length && /[a-zA-Z]/.test(this.input[this.pos])) {
          this.pos++;
        }
        const value = this.input.slice(start, this.pos);
        tokens.push({ type: 'COMMAND', value, line: this.line, col: this.col - (this.pos - start) });
        this.col += (this.pos - start);
        continue;
      }

      // Identifiers / Notes
      // Check for Note format first
      const remaining = this.input.slice(this.pos);
      const noteMatch = remaining.match(NOTE_REGEX);
      
      // If it looks like a note (A-G followed optionally by accidentals and octave)
      // But we need to distinguish between 'Tempo' (ident) and 'E' (note).
      // OmniScore convention: Notes are Capitalized.
      if (noteMatch && /[A-G]/.test(noteMatch[1])) {
         tokens.push({ type: 'NOTE', value: noteMatch[0], line: this.line, col: this.col });
         this.pos += noteMatch[0].length;
         this.col += noteMatch[0].length;
         continue;
      }

      // Rests
      if (char === 'R' || char === 'r') {
         tokens.push({ type: 'REST', value: char, line: this.line, col: this.col });
         this.pos++; this.col++;
         continue;
      }

      // Durations (numeric or letters like q, h, w)
      // This is tricky as 'q' could be an identifier. But in sticky state context, usually follows note.
      // For this ref compiler, we assume strict syntax: durations are numbers or q/h/w/e/s
      const durMatch = remaining.match(DURATION_REGEX);
      if (durMatch && (/\d/.test(durMatch[0]) || ['q','h','w','e','s'].includes(durMatch[0]))) {
         tokens.push({ type: 'DURATION', value: durMatch[0], line: this.line, col: this.col });
         this.pos += durMatch[0].length;
         this.col += durMatch[0].length;
         continue;
      }

      // Identifiers (measure labels, etc)
      if (/[a-zA-Z_]/.test(char)) {
        const start = this.pos;
        while (this.pos < this.input.length && /[a-zA-Z0-9_:]/.test(this.input[this.pos])) {
          this.pos++;
        }
        const value = this.input.slice(start, this.pos);
        tokens.push({ type: 'IDENTIFIER', value, line: this.line, col: this.col });
        this.col += (this.pos - start);
        continue;
      }

      // Numbers (standalone)
      if (/\d/.test(char)) {
         const start = this.pos;
         while (this.pos < this.input.length && /[\d.]/.test(this.input[this.pos])) {
            this.pos++;
         }
         const value = this.input.slice(start, this.pos);
         tokens.push({ type: 'NUMBER', value, line: this.line, col: this.col });
         this.col += (this.pos - start);
         continue;
      }

      // Unknown
      tokens.push({ type: 'UNKNOWN', value: char, line: this.line, col: this.col });
      this.pos++;
      this.col++;
    }
    return tokens;
  }
}

// --- PARSER & COMPILER ENGINE ---

class OmniCompiler {
  private tokens: Token[] = [];
  private pos = 0;
  private errors: CompilerError[] = [];
  private logs: string[] = [];
  private events: SoundEvent[] = [];
  
  // Sticky State
  private state = {
    octave: 4,
    duration: 1.0, // beats (quarter note default)
    velocity: 100,
    time: 0, // current absolute time in beats
  };

  constructor() {}

  compile(input: string): CompilationResult {
    this.reset();
    
    // Phase 1: Lexing
    try {
      const lexer = new Lexer(input);
      this.tokens = lexer.tokenize();
    } catch (e) {
      this.error('E001', 'Lexer initialization failed', 0);
      return this.getResult();
    }

    // Phase 2: Parsing & State Inference (Single Pass for this ref impl)
    this.logs.push(`INFO: Tokenized ${this.tokens.length} elements.`);
    
    while (this.pos < this.tokens.length) {
      const token = this.peek();
      
      if (token.type === 'COMMAND') {
        this.handleCommand();
      } else if (token.type === 'IDENTIFIER' && token.value.endsWith(':')) {
        // Measure label, e.g., "m1:"
        this.consume();
        this.logs.push(`INFO: Processing measure ${token.value}`);
      } else if (token.type === 'NOTE') {
        this.handleNote();
      } else if (token.type === 'REST') {
        this.handleRest();
      } else if (token.type === 'BARLINE') {
        this.consume(); // Just advances time visualization usually, logic ignored for minimal IR
      } else {
        // Skip unknown or extra tokens
        this.consume();
      }
    }

    this.logs.push(`SUCCESS: Compiled ${this.events.length} sound events.`);
    return this.getResult();
  }

  private reset() {
    this.pos = 0;
    this.errors = [];
    this.logs = [];
    this.events = [];
    this.state = { octave: 4, duration: 1.0, velocity: 100, time: 0 };
  }

  private getResult(): CompilationResult {
    return {
      success: this.errors.length === 0,
      events: this.events,
      errors: this.errors,
      logs: this.logs
    };
  }

  private peek(): Token {
    return this.tokens[this.pos];
  }

  private consume(): Token {
    return this.tokens[this.pos++];
  }

  private error(code: string, message: string, line: number) {
    this.errors.push({ code, message, line });
  }

  private parseDuration(val: string): number {
    if (val === 'w') return 4.0;
    if (val === 'h') return 2.0;
    if (val === 'q') return 1.0;
    if (val === 'e') return 0.5;
    if (val === 's') return 0.25;
    if (val.includes('/')) {
      const [num, den] = val.split('/').map(Number);
      return (num / den) * 4; // Assuming 1/4 = 1 beat
    }
    return parseFloat(val);
  }

  private handleCommand() {
    const token = this.consume();
    if (token.value === '@tempo') {
      const val = this.peek();
      if (val && val.type === 'NUMBER') {
        this.consume();
        this.logs.push(`CONFIG: Tempo set to ${val.value}`);
      }
    } else {
      // Ignore other commands for now
    }
  }

  private handleNote() {
    const token = this.consume();
    // Parse Pitch
    const match = token.value.match(/^([A-G][#b]?)(-?\d+)?$/);
    if (!match) {
      this.error('E102', `Invalid pitch format: ${token.value}`, token.line);
      return;
    }

    const noteName = match[1];
    let octave = match[2] ? parseInt(match[2]) : this.state.octave;
    
    // Sticky Octave Logic: Update state
    this.state.octave = octave;

    // Check for explicit duration following note
    let duration = this.state.duration;
    const next = this.peek();
    if (next && next.type === 'DURATION') {
      duration = this.parseDuration(this.consume().value);
      this.state.duration = duration; // Sticky Duration Logic
    }

    // Convert to MIDI (C4 = 60)
    const noteIndices: Record<string, number> = { 'C':0, 'C#':1, 'Db':1, 'D':2, 'D#':3, 'Eb':3, 'E':4, 'F':5, 'F#':6, 'Gb':6, 'G':7, 'G#':8, 'Ab':8, 'A':9, 'A#':10, 'Bb':10, 'B':11 };
    const base = noteIndices[noteName];
    const midi = (octave + 1) * 12 + base;

    this.events.push({
      type: 'NOTE',
      pitch: `${noteName}${octave}`,
      midiNumber: midi,
      duration: duration,
      startTime: this.state.time,
      velocity: this.state.velocity
    });

    this.state.time += duration;
  }

  private handleRest() {
    this.consume(); // 'R'
    let duration = this.state.duration;
    const next = this.peek();
    if (next && next.type === 'DURATION') {
      duration = this.parseDuration(this.consume().value);
      this.state.duration = duration;
    }

    this.events.push({
      type: 'REST',
      duration: duration,
      startTime: this.state.time
    });

    this.state.time += duration;
  }
}

// --- REACT COMPONENTS ---

const INITIAL_CODE = `// OmniScore Example Spec v1.1
@tempo 120
@inst piano

// Measure 1: Introduction
m1:
  C4 q      // C4 Quarter note
  E         // E4 Quarter (sticky duration)
  G         // G4 Quarter
  C5        // C5 Quarter

// Measure 2: Rhythm Variation
m2:
  E5 8      // Eighth note, new sticky duration
  D5        // Eighth
  C5        // Eighth
  B4        // Eighth
  A4 q      // Quarter
  R q       // Rest Quarter

// Measure 3: Chords (Linearized)
m3:
  C3 w      // Bass note whole
`;

const App = () => {
  const [code, setCode] = useState(INITIAL_CODE);
  const [result, setResult] = useState<CompilationResult | null>(null);
  const [activeTab, setActiveTab] = useState<'visual' | 'json' | 'logs'>('visual');
  const [isCompiling, setIsCompiling] = useState(false);

  // Instantiate compiler
  const compiler = useMemo(() => new OmniCompiler(), []);

  const handleCompile = () => {
    setIsCompiling(true);
    // Slight delay to simulate heavy lifting if needed, but synchronous is fine for this demo
    setTimeout(() => {
      const res = compiler.compile(code);
      setResult(res);
      setIsCompiling(false);
      if (res.errors.length > 0) {
        setActiveTab('logs');
      }
    }, 300);
  };

  useEffect(() => {
    handleCompile();
  }, []); // Compile on mount

  return (
    <div className="flex h-screen w-full bg-slate-950 text-slate-200 overflow-hidden">
      {/* LEFT PANE: EDITOR */}
      <div className="w-1/2 flex flex-col border-r border-slate-800">
        <div className="h-12 bg-slate-900 border-b border-slate-800 flex items-center px-4 justify-between">
          <div className="flex items-center gap-2 text-slate-100 font-semibold">
            <Music className="w-5 h-5 text-indigo-400" />
            <span>OmniScore IDE</span>
            <span className="text-xs bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full">v1.1.0-rc</span>
          </div>
          <div className="flex gap-2">
             <button 
              onClick={handleCompile}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1.5 rounded-md text-xs transition-colors font-medium">
              <Cpu className={`w-3.5 h-3.5 ${isCompiling ? 'animate-spin' : ''}`} />
              Build `omnic`
            </button>
          </div>
        </div>
        
        <div className="flex-1 relative font-mono text-sm">
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full h-full bg-slate-950 p-4 resize-none focus:outline-none text-slate-300 leading-relaxed selection:bg-indigo-500/30"
            spellCheck={false}
          />
        </div>
        
        <div className="h-8 bg-slate-900 border-t border-slate-800 flex items-center px-4 text-xs text-slate-500 gap-4">
          <span>Main.omni</span>
          <span>UTF-8</span>
          <span className="ml-auto">Ln {code.split('\n').length}</span>
        </div>
      </div>

      {/* RIGHT PANE: OUTPUT */}
      <div className="w-1/2 flex flex-col bg-slate-900">
        {/* Toolbar */}
        <div className="h-12 border-b border-slate-800 flex items-center px-2">
          <TabButton active={activeTab === 'visual'} onClick={() => setActiveTab('visual')} icon={Layers} label="Piano Roll" />
          <TabButton active={activeTab === 'json'} onClick={() => setActiveTab('json')} icon={FileJson} label="Linearized IR" />
          <TabButton active={activeTab === 'logs'} onClick={() => setActiveTab('logs')} icon={Terminal} label="Compiler Logs" />
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-auto p-4">
          {activeTab === 'visual' && <Visualizer events={result?.events || []} />}
          
          {activeTab === 'json' && (
            <pre className="font-mono text-xs text-green-400 bg-slate-950 p-4 rounded-lg overflow-auto h-full border border-slate-800">
              {result ? JSON.stringify(result.events, null, 2) : '// No build output'}
            </pre>
          )}

          {activeTab === 'logs' && (
            <div className="font-mono text-xs space-y-2">
              {result?.logs.map((log, i) => (
                <div key={i} className="text-slate-400 border-l-2 border-slate-700 pl-2">{log}</div>
              ))}
              {result?.errors.map((err, i) => (
                <div key={i} className="text-red-400 bg-red-900/10 p-2 rounded border-l-2 border-red-500">
                  <span className="font-bold">[{err.code}]</span> {err.message} (Line {err.line})
                </div>
              ))}
              {result?.success && (
                <div className="text-green-400 mt-4 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  Build Successful.
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// --- SUBCOMPONENTS ---

const TabButton = ({ active, onClick, icon: Icon, label }: any) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-2 px-4 h-full text-xs font-medium border-b-2 transition-colors ${
      active 
        ? 'border-indigo-500 text-indigo-400 bg-slate-800/50' 
        : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/30'
    }`}
  >
    <Icon className="w-3.5 h-3.5" />
    {label}
  </button>
);

const Visualizer = ({ events }: { events: SoundEvent[] }) => {
  if (events.length === 0) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-slate-500">
        <Box className="w-12 h-12 mb-4 opacity-20" />
        <p>No events generated.</p>
      </div>
    );
  }

  // Calculate layout
  const BEAT_WIDTH = 60;
  const ROW_HEIGHT = 20;
  const totalDuration = events[events.length - 1].startTime + (events[events.length - 1].duration || 0);
  
  // Note range
  const notes = events.filter(e => e.type === 'NOTE') as NoteEvent[];
  if (notes.length === 0) return <div className="p-4 text-slate-500">Only rests found.</div>;
  
  const minMidi = Math.min(...notes.map(n => n.midiNumber)) - 2;
  const maxMidi = Math.max(...notes.map(n => n.midiNumber)) + 2;
  const range = maxMidi - minMidi;

  return (
    <div className="h-full overflow-auto bg-slate-950 rounded-lg border border-slate-800 relative shadow-inner">
      <div 
        className="relative"
        style={{ 
          width: Math.max(800, totalDuration * BEAT_WIDTH + 100), 
          height: Math.max(400, range * ROW_HEIGHT + 40) 
        }}
      >
        {/* Grid Background */}
        <div className="absolute inset-0 pointer-events-none opacity-20" 
             style={{ 
               backgroundImage: `linear-gradient(to right, #334155 1px, transparent 1px), linear-gradient(to bottom, #334155 1px, transparent 1px)`,
               backgroundSize: `${BEAT_WIDTH}px ${ROW_HEIGHT}px`
             }} 
        />

        {/* Notes */}
        {events.map((ev, i) => {
          if (ev.type === 'NOTE') {
            const top = (maxMidi - ev.midiNumber) * ROW_HEIGHT;
            const left = ev.startTime * BEAT_WIDTH;
            const width = ev.duration * BEAT_WIDTH - 2; // -2 for gap
            
            return (
              <div
                key={i}
                className="absolute bg-indigo-500 rounded-sm border border-indigo-400 shadow-sm hover:bg-indigo-400 transition-colors group cursor-pointer"
                style={{ top, left, width, height: ROW_HEIGHT - 2 }}
                title={`${ev.pitch} (${ev.duration} beats)`}
              >
                <span className="text-[10px] text-indigo-900 font-bold px-1 hidden group-hover:block leading-none mt-0.5">
                  {ev.pitch}
                </span>
              </div>
            );
          } else {
            // Rests
            const left = ev.startTime * BEAT_WIDTH;
            const width = ev.duration * BEAT_WIDTH;
             return (
              <div
                key={i}
                className="absolute bg-slate-800/30 border-l-2 border-slate-700 h-full flex items-center justify-center pointer-events-none"
                style={{ top: 0, left, width }}
              >
              </div>
            );
          }
        })}

        {/* Time Markers */}
        {Array.from({ length: Math.ceil(totalDuration) + 1 }).map((_, i) => (
          <div key={i} className="absolute top-0 text-[10px] text-slate-500" style={{ left: i * BEAT_WIDTH + 4 }}>
            {i}
          </div>
        ))}
      </div>
    </div>
  );
};

const root = createRoot(document.getElementById('root')!);
root.render(<App />);
